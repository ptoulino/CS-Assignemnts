select *
from client
where client_credit_rtg > 3.4;



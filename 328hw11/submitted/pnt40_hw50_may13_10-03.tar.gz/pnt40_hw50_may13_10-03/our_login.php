<?php

function our_login()
{

?>

<form method="post" action="<?= htmlentities($_SERVER['PHP_SELF'],ENT_QUOTES)?>
">


            <fieldset>
                <legend> Enter Oracle username/password: 
                    </legend>

                <label for="username"> Username: </label>
                <input type="text" name="username" id="username"
                       required="required" /> 

                <label for="password"> Password: </label>
                <input type="password" name="password" id="password" 
                       required="required" />
            </fieldset>



<div class="submit">
<input type="submit" value="Login" onclick="return myFunction();"/>
</div>



</form>

<?php
}
?>


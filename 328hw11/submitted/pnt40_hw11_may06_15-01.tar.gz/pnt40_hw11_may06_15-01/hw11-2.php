<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!--
    by: Philip Toulinov 
    last modified: 2020-05-05

    you can run this using the URL:
        https://nrs-projects.humboldt.edu/~pnt40/328hw11/hw11-2.php
-->

<head>
    <title> PHP XML </title>
    <h3>Philip Toulinov </h3>
    <meta charset="utf-8" />

    <link href="https://nrs-projects.humboldt.edu/~st10/styles/normalize.css"
          type="text/css" rel="stylesheet" />
</head>

<body>

<?php
    $myXmlEmail = simplexml_load_file("hw11-2.xml");

    $to = $myXmlEmail->to;
    $from = trim($myXmlEmail->from);
    $heading = trim($myXmlEmail->heading);
    $date = trim($myXmlEmail->date);
?>

  <ul>
    <pre>
	<li> $phpVersion1->{'to'} is: [<?= $to ?>] </li>
        <li> $phpVersion1->{'from'} is: [<?= $from ?>] </li>
        <li> $phpVersion2['heading'] is: [<?= $heading ?>] </li>
	 <li> $phpVersion2['date'] is: [<?= $date ?>] </li>
    </pre>
  </ul>



</body>
</html>

 

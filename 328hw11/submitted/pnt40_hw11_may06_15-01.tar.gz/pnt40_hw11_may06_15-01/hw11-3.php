<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!--

    by: Philip Toulinov 
    last modified: 2020-05-05

    you can run this using the URL:
        https://nrs-projects.humboldt.edu/~pnt40/328hw11/hw11-3.php  
-->

<head>
    <title> PHP AND JSON </title>
    <meta charset="utf-8" />

    <link href="https://nrs-projects.humboldt.edu/~st10/styles/normalize.css"
          type="text/css" rel="stylesheet" />
</head>

<body>
	<h3>Philip Toulinov</h3>
<?php

    $myJSONString = file_get_contents("hw11-3.json");
    $phpVersion1 = json_decode($myJSONString);
    $sender = $phpVersion1->{'sender'};
    $recipient = $phpVersion1->{'recipient'};
    $read_time = $phpVersion1->{'read_time'};

?> 

   <ul>
    <pre>
	<li> $phpVersion1->{'sender'} is: [<?= $sender ?>] </li>
        <li> $phpVersion1->{'recipient'} is: [<?= $recipient ?>] </li>
        <li> $phpVersion2['read_time'] is: [<?= $read_time ?>] </li>
     </pre>
   </ul> 



</body>
</html>

 

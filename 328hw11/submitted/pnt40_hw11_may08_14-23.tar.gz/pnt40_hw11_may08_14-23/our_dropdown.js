"use strict";


function our_dropdown() {

 alert("𝕐𝕆𝕌 𝕎𝕀𝕃𝕃 ℕ𝕆𝕎 𝔹𝔼 ℝ𝔼𝔻𝕀ℝ𝔼ℂ𝕋𝔼𝔻 𝕋𝕆 𝕐𝕆𝕌ℝ ℂℍ𝕆𝕀ℂ𝔼");
}




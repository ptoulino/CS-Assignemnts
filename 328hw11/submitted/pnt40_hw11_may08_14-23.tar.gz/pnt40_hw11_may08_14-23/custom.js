"use strict";

window.onload = custom; 

function custom() {

 alert("ℙ𝕃𝔼𝔸𝕊𝔼 ℂ𝕆ℕ𝔽𝕀ℝ𝕄 ℂℝ𝔼𝔻𝔼ℕ𝕋𝕀𝔸𝕃𝕊 𝕋𝕆 ℂ𝕆ℕ𝕋𝕀ℕ𝕌𝔼");
}

window.stop = custom;

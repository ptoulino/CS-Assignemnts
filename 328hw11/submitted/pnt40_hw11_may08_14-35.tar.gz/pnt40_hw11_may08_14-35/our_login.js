"use strict";

function myFunction() {
  alert("If login correct, you will be redirected to the selection page");
}






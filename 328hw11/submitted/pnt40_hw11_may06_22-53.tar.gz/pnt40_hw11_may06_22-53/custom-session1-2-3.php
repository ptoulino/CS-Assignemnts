<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<!--
    dept-details.php:
    3-state application using PHP, sessions, and Oracle

    by: Sharon Tuttle
    last modified: 2020-04-13
    Adapted by: Philip Toulinov

    requires:
    *   name-pwd-fieldset.html
    *   create_login.php
    *   create_dropdown.php
    *   destroy_and_exit.php
    *   hsu_conn_sess.php
    *   get_dept_info.php
    *   328footer.html
    *   328footer-plus-end.html

    you can run this using the URL:
http://nrs-projects.humboldt.edu/~pnt40/328hw11/custom-session1-2-3.php
-->

<head>
    <title> dept-details </title>
    <meta charset="utf-8" />

    <?php
    /* these are bringing in needed PHP functions */
    
        require_once("our_login.php");
        require_once("our_dropdown.php");
	require_once("our_display.php");
        require_once("hsu_conn_sess.php");
    ?>

  <link href="http://users.humboldt.edu/smtuttle/styles/normalize.css"
          type="text/css" rel="stylesheet" />
	

  <link href="personal.css"
          type="text/css" rel="stylesheet" />

  <link href=
        "http://nrs-projects.humboldt.edu/~st10/styles/normalize.css"
          type="text/css" rel="stylesheet" />

</head>

<body>
    <h1> HW 11 Problem 4</h1>
    <h2> Philip Toulinov </h2>

<div class="row">
  <div class="column">
    <img src="image5.png" alt="1" style="width:100%">
  </div>
  <div class="column">
    <img src="image6.png" alt="2" style="width:100%">
  </div>
  <div class="column">
    <img src="image4.png" alt="3" style="width:100%">
</div>
</div>


 <?php


    if (! array_key_exists('next-stage', $_SESSION))
    {
        our_login();
        $_SESSION['next-stage'] = "our_dropdown";
?>
  <script src="custom.js"> </script>

<?php
    }


    elseif ($_SESSION['next-stage'] == "our_dropdown")
    {
       
	$username = strip_tags($_POST["username"]);
	$password = $_POST["password"];
	$_SESSION["username"] = $username;
	$_SESSION["password"]= $password;


	 our_dropdown();
        $_SESSION['next-stage'] = "our_display";
    }


    elseif ($_SESSION['next-stage'] == "our_display")
    {

	
	$presentor_id=$_POST["empl"];	
	$_SESSION["empl"] = $presentor_id;
    
	our_display();
	session_destroy();

    }

    else
    {
          
	our_login();

        session_destroy();
        session_regenerate_id(TRUE);
        session_start();
     
	$_SESSION['next-stage'] ="our_dropdown";
  

    }
?>
<div class="parent">
<img src="image1.png" alt="4" style="width:99%">
</div>

<?php 
    require_once("328footer.html");
?>

</body>
</html>

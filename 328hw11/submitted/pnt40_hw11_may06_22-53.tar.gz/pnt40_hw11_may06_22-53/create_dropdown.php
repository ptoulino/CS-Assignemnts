<?php

/*===== 
    START w/ a STUB! 

function create_dropdown()
{
    ?>
    <p> called create_dropdown() </p>
    <?php
}

=====*/

/*=====
    ...then, after creating and debugging create_login function,
        creating create_dropdown function
=====*/

/*=====
    function: create_dropdown: void -> void
    purpose: expects nothing, and returns nothing, BUT does
        expect the $_POST array to contain a key "username"
        with a valid Oracle username, and a key "password"
        with a valid Oracle password;
      
        ...if it cannot find these, or if it cannot make a
        valid connection to Oracle using these, it 
        destroys the session and exits;

        ...otherwise, it tries to output to the resulting
        document a dynamically-created dropdown with the current
        departments' names 

    requires: 328footer-plus-end.html, destroy_and_exit.php,
              hsu_conn_sess.php

    last modified: 2020-04-13
=====*/

function create_dropdown()
{
    // first: IS there at least an attempt at a username/password?
    //
    // why check this, if create_login creates a form with 
    //     input elements for these that have required="required"?
    // ...because what if something is NOT coming from "my" 
    //     login form???
    //
    // (in this case, though, not awful if you omit this --
    //     Oracle login would fail if these not entered, anyway!
    //     BUT this avoids an Oracle error message for that.)

    if ( (! array_key_exists("username", $_POST)) or
         (! array_key_exists("password", $_POST)) or
         ($_POST["username"] == "") or
         ($_POST["password"] == "") or
         (! isset($_POST["username"])) or
         (! isset($_POST["password"])) )
    {
        destroy_and_exit("must enter a username and password!");
    }

    // if reach here, DO have a username and password; 

    $username = strip_tags($_POST["username"]);

    // ONLY using password to log in, so NOT sanitizing it (gulp?)
    
    $password = $_POST["password"];

    // save these for later (should be OK to do now, I THINK, because if
    //     connection fails, WILL be destroying session, and these,
    //     later)
    
    $_SESSION["username"] = $username;
    $_SESSION["password"] = $password;

    //   NOW: can you connect to Oracle with them?
    //     (NOTE that hsu_conn_sess destroys session and
    //     exits the PHP document if it fails...!)

    $conn = hsu_conn_sess($username, $password);

    // if reach here -- CONNECTED!

    // try to query department names; I decided to grab their
    //     department numbers, too

    $dept_query_str = "select dept_num, dept_name
                       from dept
                       order by dept_name";
    $dept_query = oci_parse($conn, $dept_query_str);
    oci_execute($dept_query);

    // build a form with a dropdown

    ?>
    <form method="post"
          action="<?= htmlentities($_SERVER['PHP_SELF'], 
                                   ENT_QUOTES) ?>">      
        <fieldset>
            <legend> Select desired department </legend>
            <select name="dept_choice">

            <?php
            while (oci_fetch($dept_query))
            {
                $curr_dept_num = oci_result($dept_query, "DEPT_NUM");
                $curr_dept_name = oci_result($dept_query, "DEPT_NAME");

                ?>
                <option value="<?= $curr_dept_num ?>"> 
                    <?= $curr_dept_name ?> </option>
                <?php
            }

            ?>
            </select>
        </fieldset>
        <input type="submit" value="submit choice" />        
    </form>

    <?php
    oci_free_statement($dept_query);
    oci_close($conn);
}

?>

"use strict";



function myfunction() 
{

<button type="button" 
onclick="document.getElementById('h2').style.color = 'red'">
Click Me!</button> 
}


"use strict";

window.onload = custom; 

function custom() {


var user_verification = prompt("ΛЯΣ YӨЦ ΛП ΛЦƬΉӨЯIZΣD ЦƧΣЯ? ","");

    alert("ᑭᒪEᗩᔕE EᑎTEᖇ ᑕᖇEᗪEᑎTIᗩᒪᔕ TO ᑕOᑎTIᑎᑌE"); 
}



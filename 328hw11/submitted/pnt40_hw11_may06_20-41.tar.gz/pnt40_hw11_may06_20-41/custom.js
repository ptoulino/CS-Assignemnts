"use strict";

window.onload = custom; 

function custom() { 
    var user_verification = prompt("𝙲𝚁𝙴𝙳𝙴𝙽𝚃𝙸𝙰𝙻𝚂 𝙰𝚁𝙴 𝙽𝙴𝙴𝙳𝙴𝙳, 𝚆𝙾𝚄𝙻𝙳 𝚈𝙾𝚄 𝙻𝙸𝙺𝙴 𝚃𝙾 𝙲𝙾𝙽𝚃𝙸𝙽𝚄𝙴?", "");
    alert("𝙸𝙵 𝚈𝙴𝚂, 𝙿𝙻𝙴𝙰𝚂𝙴 𝙴𝙽𝚃𝙴𝚁 𝙲𝚁𝙴𝙳𝙴𝙽𝚃𝙸𝙰𝙻𝚂 𝚃𝙾 𝚂𝙴𝙻𝙴𝙲𝚃 𝙴𝙼𝙿𝙻𝙾𝚈𝙴𝙴"); 
}



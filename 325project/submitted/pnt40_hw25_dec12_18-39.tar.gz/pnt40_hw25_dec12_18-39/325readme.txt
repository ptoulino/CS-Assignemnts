Philip Toulinov
Cs 325-Fall 2019
Last modified: 12/12/19

Files:
325queries.sql-8queries
325query-results.txt-results of the 8 queries in a text file
325report1.sql -first report
325report2.sql -second report
325report3.sql -third report
325report1-results.txt -first report results in a text file
325report2-results.txt -second report results in a text file
325report3-results.txt -third report results in a text file
325discussion.txt-300 words on how this DBMS can be implemented
325readme.txt-list containt usefull information
325misc.txt -extra content added to project
325populate.sql - population of project tables
325show-contents.sql  -contents of project tables
325result-contents.txt  -contents of project tables in a text file
325design-rs.txt-project design in a text file 
325design.sql  -project design 
325model.pdf - project model  
325biz-rules.pdf -project proposed business rules
325scenario.txt -project scenario written form
project_map.pdf -Map of dog walking routes pickup/dropoff locations

Instructions:
First run file 325design.sql
Run 325show-contents.sql to see results of tables( they will be empty)
Run 325populate.sql to populate your tables
Run 325show-contents.sql to prove that your tables can populate accordingly
Run 325queries.sql to see some example queries
Run 325report1.sql or 325report2.sql or 325report3.sql to see some example queries!

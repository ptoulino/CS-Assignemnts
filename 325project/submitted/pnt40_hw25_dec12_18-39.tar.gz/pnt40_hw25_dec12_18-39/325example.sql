prompt Query 5(Compound where dropoff/pickup location are both A)

select drop_off_loc,pick_up_loc,appointment_id,appointment_time
from grooming_appointment
where drop_off_loc ='A' and pick_up_loc ='A';
